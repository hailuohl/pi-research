# Anscombe group 2 LOOCV comparison

Official R source: https://svn.r-project.org/R/trunk/src/library/datasets/data/anscombe.R
SHA-256: 02f29379f282fcf909ff988b3fde2be2d5591975ba27ed0efd8714a91629223e
Question: on these eleven fixed observations, does degree 2 lower leave-one-out MSE by at least 10% versus degree 1? No external generalization claim.
