Pi Research fixed-source export

report.md contains the saved report. manifest.json binds the selected fixed source, archived results and review evidence. Mutable workspaces and local configuration are not included.

Source modes are logical Git modes (100644 / 100755) recorded in the manifest. Windows tar headers do not reliably preserve executable bits; restore those modes from the manifest on platforms that support them. A successful process does not prove a scientific hypothesis.
