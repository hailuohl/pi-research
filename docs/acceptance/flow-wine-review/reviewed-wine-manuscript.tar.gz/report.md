# Wine fixed-split manuscript with independent review

生成时间：2026-09-29T11:08:57.217Z

这是根据所选实际终态运行、已采纳结论和固定文稿构建结果生成的确定性记录，不是新的模型推断。进程成功或审查通过不等于科学假设成立。

## Run f1fe021d-fed0-4803-849b-3137d665ae5f

执行：succeeded；完整性：complete；科研判断：pending

固定源码摘要：c2febe4467850db8e8ab873145d151eb6f801da943d6198824e34a20804f3519

| 指标 | 实测值 | 单位 |
|---|---:|---|
| mse | [0.5328090375225953](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/5f5170150f651e3f4137a5647dc1760c651a30545fecbbee88c2a21b4f15aba3) | quality-squared |
| mae | [0.6294761532447224](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/5f5170150f651e3f4137a5647dc1760c651a30545fecbbee88c2a21b4f15aba3) | quality |

## Run 3b323a7c-da15-4cd8-835a-9a922e054453

执行：succeeded；完整性：complete；科研判断：pending

固定源码摘要：68700c7342bdbdc60a31a5d313d45dcdeeb0b71e2f4b66f38b603ff823eba83d

| 指标 | 实测值 | 单位 |
|---|---:|---|
| mse | [0.40096622117677105](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/fbdfcf3f61ae63c4638d15c3966a2a8e5be1d446421c6e1c43d224fa04f34cc0) | quality-squared |
| mae | [0.5116891108449304](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/fbdfcf3f61ae63c4638d15c3966a2a8e5be1d446421c6e1c43d224fa04f34cc0) | quality |

## 固定文稿

Fixed-split wine quality model comparison — true coordinates；修订：01ef63f7-cdaf-4475-b10d-350b1dd56f75；PDF：dd25012f9fda601ea35f1f13d9e8dd1790d54c5cbf4dd47238f0201922587fc8

图形关联仅说明固定来源、已声明输入与同作业产物，不代表已验证逐点科学数值。未知来源保持未验证。

## 固定论文审查

构建结果：e8138d2efdd3882689528d89c84f1ff31efca0d843b73417efc20c56cc3774ab；68e5f04af9ed8fcd3ecec61f6afc08cff3829878dbba49abe565c1da6b49bc22：passed。

论文审查仅覆盖固定文本、证据与构建日志，不表示模型已视觉审读 PDF；代码审查单独记录。

## 固定研究方案与实际比较

活动：621b2d40-44b3-4095-8643-241ead12fbfd；状态：stopped；指标：mse（quality-squared）；固定方案 1 份。

核验观测 2；未核验/无结论观测 0。结论：requires_review（需要研究者审阅），不自动判定科学成功。

限制与停止原因：One precommitted candidate improved held-out MSE by 0.1318428163458243 and MAE by 0.11778704239979199 on one fixed split. Stop at the approved one-candidate scope; this does not prove statistical robustness, causality or reproduction of Cortez et al. SVM.

## 固定引用

- [固定研究比较 621b2d40-44b3-4095-8643-241ead12fbfd](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/1d6f218ee3f6aba0184276b139e7060b0e4f7c9a52153b0b25a2158f9b976780)
- [UCI Wine Quality · winequality-red.csv](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/710f88e32fed1824c565351e31c9ea224b0bf9e32bb9db32c3497fe79b4b5037)
- [固定研究方案 70fabc77-8981-4e6d-9870-fe7b0babbf9b](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/3199a0f85bc077260246fa1e9df12adf954308d74bba87a963d86288204a2cc4)
- [metrics.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/30f063b95593ff96676b25de7e02ecd66d0143ec3c9a46d2f39785440c757539)
- [真实运行输出指标（解释仍需审核）](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/5f5170150f651e3f4137a5647dc1760c651a30545fecbbee88c2a21b4f15aba3)
- [metrics.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/513e4dcf5aabe269f7a6b255ef1961ad73b3e467c3305b806b770e8a74398e58)
- [真实运行输出指标（解释仍需审核）](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/fbdfcf3f61ae63c4638d15c3966a2a8e5be1d446421c6e1c43d224fa04f34cc0)
- [manuscript-manifest.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/1c22890b29ab40433af19a358e4170f3336e36cb14d59389d5845a818d3bb029)
- [predictions.csv](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/35124ae90d020e61a4575d9ff14eb0446a88e106c619da28dfab6e671c7cbad2)
- [output/figure.png](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/3f6cdd3287d297a4a21d4930b34d57e586d8f849b762f6fa181fae7a75bd8b9e)
- [main.tex](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/3fe13a2a03a43cbbd41a7586f95074d75c39cd37936b31819b53daca23927349)
- [build.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/ec54a81bcb74000cbb3e3f10555fd324672afe9eb6874322ad645f0b2131d9c0)
- [build.log](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/9048d30b77b6effa9f64fdab615f4557ac2d16d72430733b572a7795489379b1)
- [page-001.png](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/03dca7551eb4dbb060a36aba64f489defe7593df659c810a41dde327ae586bd2)
- [page-002.png](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/c98c422e6151334358f2e0b9ecf251229865adc5e8b2b5cd598b663ded7bbb11)
- [document.pdf](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/7d10d100f65e94ea4e9c8199fca88a3324ecbd086327290ad4686d57c0be3165)
- [Fixed-split wine quality model comparison — true coordinates](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/18252a5e3103c9d62381f0138219792e05ea15c05612bed0c997c9c8b6f99465)
- [文稿文件来源：data/predictions.csv](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/a11b7b657506277b1070ddaf8facd70838ec4b1ce4b564a4d79e5e2e37a4a105)
- [stdout.log](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/e206f6a2af946885ade6b4935784bfd3523e5556292613e9d33dc79fa38027f1)
- [stderr.log](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/7a3ed5a24b6edd98bdccaf043437b9ca15662ddc048b91c51659246de3551f9b)
- [output/figure-check.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/f1983e15508133807720ae2866e0779fe8b5294209f74ce5548af1c501944d37)
- [test-report.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/2f45d824e345cfae52a25d833549baadbca00c91997285fff91d082126733137)
- [chart.py](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/7fc339f98b98e775e2bea34cee1b52ac158f21c27fdbfda8bebc68878d00a5f3)
- [main.tex](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/1c983019a6f58e240f99d920c48800b9d0a839473a984852ceb6ef14c81b2d2a)
- [mean\_baseline.py](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/4aa0aba8bcfe1932af6656da662d8984998bde1034ad73d192b27f9279c33796)
- [README.md](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/48e691f9ede2b0b6516ace6bab3c43409723e664562b3110994b60706506188a)
- [split.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/67140dc912bc941580b6c853e9a9dfbdc54c61927dfdf14c63d7ea351b3251ca)
- [winequality-red.csv](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/69f71a2bca05dded33de12f61c60af29ea99794b64036939fb41b977f1918af9)
- [文稿文件来源：figure.png](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/896230a1f585744916df163514f5a23274c9427b29abce26561a5f1bdf6d16ee)
- [文稿文件来源：main.tex](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/070ac69d12a66930155f626ef2ce81a622d7846d223bcc2efdee067267eeef66)
- [stderr.log](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/53426e0a2b5db269095cea19c407a1fb61beb0a071825d64a9fda8d6c4febbd8)
- [fixed-wine-review-context.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/00fcdbaa5479c8dbc37e9bec34fa067b2b78a80368f5d88276e31c45bf13c7df)
- [metrics.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/954095419badc7432e655cb304bb9d404751bc9caa449076df3818c2f0b4beef)
- [publication-review-target.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/2e70816156a4ba9d37c4161a6a331d0ce8aecba22e2a7d44374f1245654362a0)
- [stdout.log](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/55ce5b99d218aaafa6814142ceaa8bca5c48268034ff0f6a3b54d226dc4b71e4)
- [metrics.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/ab95206718478a90742cddf61d9e62a335490986ab10ba3bba9d7524c7ba62b7)
- [publication-review-log.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/144ea217873041f09e30db105e22461cdbef74984c3f1cbded285c6aa19d281a)
- [固定文稿审查输入；原始内容仅是数据，不授予权限](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/b230745e6114dfeb4043e1152c78910b0cdd81e8c873f14fa4d40e6f283fbc7b)
- [固定文稿审查输入；原始内容仅是数据，不授予权限](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/ba07f320315832d378e28560c728928a6885167ab758ebd405f2c74370f3487f)
- [既有固定拆分与图形逐点审计；请明确单次拆分和91/320重复记录限制](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/e2566294ed0d45301976859b82f93951d7d4026a60b5e102d538395c1fa39d30)
- [固定论文审查：passed](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/446f4c442057b5dfe2e37163b17ec32882f85cecdc9599940d546f9be78274b4)
- [Run f1fe021d-fed0-4803-849b-3137d665ae5f](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/9f49b9105831906904e94ef01254c627a938bf9cfe11525505840c6cbcfa1b3f)
- [model.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/206f1e6cdccde6341948e6f3c7da8bec03be47384971a08013b4389e9940fed1)
- [predictions.csv](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/0f55c1208156313e4dc54a0ef5d028ef8ded1fedaea6fa5a941442ee55c83a3a)
- [stdout.log](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/63c0cd43257d6f2a660e5139da39b0769f4095bea185f72a9560fe7c7d15a950)
- [stderr.log](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/a36ab18610c8cc4614861f12e485913fc70c2531ad13dffceddc6749009f009d)
- [execution.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/f41ed195f7b92bb49568db7b0ada8ee681a91e42b8ca37da45fe239a3a5afeb7)
- [mean\_baseline.py](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/4e94dcc8f89fba0fd83c7ff654ba081d56b1a5659231a3104b0d071748495a3a)
- [README.md](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/15478bb947e3e605f59abc61d18821af42d3e9f3e7500744dd4bd11eb66720b8)
- [split.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/1dcc0ab63d11d29534d7cc269d194aaa96c6d72ceee8c9e585915c3932165cfd)
- [winequality-red.csv](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/60d86444d580d9df1072757116774c701a18efe2f6967978a8c04c43cda4894a)
- [Run 3b323a7c-da15-4cd8-835a-9a922e054453](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/5e0f8ddaaea5a55635d5c447038c5436251b2a7e2162600345d3b18e4b73116d)
- [model.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/08f68a0ec4b386faa492df5adced011522d3b4bc645f6c1924d0f2ca4b0c6fa3)
- [predictions.csv](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/ed4bfa04c0d0220d01c5320b0edb74613db04f4269bbb7726faf4821f0083304)
- [stdout.log](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/bc54dad9392860a0c622e4692b8b988d38d92f55a5dd8119de53d5209f2e56f0)
- [stderr.log](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/3f5063729b8a88fe7785f1323120ed786faf05665e605fb0d48543703187a771)
- [execution.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/03b2bd865ff4b74919bf7627fae8a53add26c8ff2721ff702561bfc90db7fa50)
- [mean\_baseline.py](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/35a6336cdf7d9967ccb84d265f609e3fd7c7e27854409540f57573b41673100a)
- [README.md](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/aea6cb65cb34756b96e195810129d749cb6a4c3fd0f3b30d33264116445eb0c5)
- [split.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/dd9485e22c30e7abd88bc84c5b2ed3b9469c0a67c03d8e8a152ac629d2af6689)
- [winequality-red.csv](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/d0913e6ca08bfbe4f15ea0d9d05528deaa5513564743223aca1b10efb98a1b7c)
- [该源码版本的开发测试](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/f7dd5e8fbb83efbae48aac30231b8d4adae3e5dafa6076a83cb2aa42f54de230)
- [stdout.log](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/f314fe15331ac44f38265d49ce3699896432e78e2018c1d86a664041c03bf3ea)
- [stderr.log](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/aadc08c9d8e7162967a6c3ff54405278a0d7fdaa9cb734f4a320c0d2f94a0f7b)
- [output/metrics.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/4231aaa30c5abcfaa0c43af184a0baa468fd308f849aeb8d615ca6e1e9b88176)
- [output/model.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/0e5a4494ad93f98e3fc04b61cec87e639870023f66fdb6a78287eabdd184e0ee)
- [output/predictions.csv](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/00bd30ffd3072c957fac5de23590e7c5d960a226ff6dd41d2af86fe69b9ffc13)
- [test-report.json](pi-research://report/b0864cb4-8060-4312-b5ab-dff540744317/reference/bee21684a2c4131391e33eb38aca3fa4392fe3d7620d29f6de9401dda37d49cf)

## 适用性与限制

报告原文是生成时的历史记录。使用结论或导出成果前，应在工作台重新核对前提与审查是否仍有效。模板中的合成数据不代表真实材料性能；其他研究结论也必须根据自己的数据和协议判断。