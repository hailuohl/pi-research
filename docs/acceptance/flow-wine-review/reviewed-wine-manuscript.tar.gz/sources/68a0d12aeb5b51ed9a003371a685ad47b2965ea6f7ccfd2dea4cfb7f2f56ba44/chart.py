#!/usr/bin/env python3
"""Scatter plot of predicted vs true wine-quality scores.

Reads the frozen prediction CSV mounted read-only at
/data/d7f15dd4-1893-413c-89f3-9b94c5f9d457, verifies its byte SHA-256,
structure and row count, and writes /output/figure.png plus
/output/figure-check.json. Standard library only; no network access.
"""

import hashlib
import json
import struct
import zlib

SRC = "/data/d7f15dd4-1893-413c-89f3-9b94c5f9d457"
EXPECTED_SHA256 = "2f3257719c7ba1b6fd5cf119cfafcdcb243f6387c7d0db075272340c4c256cb6"
EXPECTED_ROWS = 320
ARTIFACT_ID = "d7f15dd4-1893-413c-89f3-9b94c5f9d457"
PNG_PATH = "/output/figure.png"
CHECK_PATH = "/output/figure-check.json"

WIDTH, HEIGHT = 1000, 900
MARGIN_L, MARGIN_R, MARGIN_T, MARGIN_B = 110, 60, 60, 100
PLOT_W = WIDTH - MARGIN_L - MARGIN_R
PLOT_H = HEIGHT - MARGIN_T - MARGIN_B
BG = (255, 255, 255)
FG = (0, 0, 0)
GRID = (220, 220, 220)
POINT = (30, 90, 180)
DIAG = (180, 30, 30)


def fail(msg):
    raise SystemExit("ERROR: " + msg)


def load_rows():
    with open(SRC, "rb") as f:
        raw = f.read()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != EXPECTED_SHA256:
        fail("source SHA-256 mismatch: %s" % digest)
    text = raw.decode("utf-8")
    lines = text.split("\r\n")
    if lines and lines[-1] == "":
        lines.pop()
    if lines[0] != "index,target,prediction":
        fail("unexpected header: %r" % lines[0])
    rows = []
    for n, line in enumerate(lines[1:], start=2):
        parts = line.split(",")
        if len(parts) != 3:
            fail("line %d does not have 3 fields" % n)
        idx = int(parts[0])
        target = float(parts[1])
        prediction = float(parts[2])
        rows.append((idx, target, prediction))
    if len(rows) != EXPECTED_ROWS:
        fail("expected %d rows, found %d" % (EXPECTED_ROWS, len(rows)))
    return digest, rows


# --- minimal PNG writer (grayscale-free truecolor, no interlace) ---

def chunk(tag, data):
    return (struct.pack(">I", len(data)) + tag + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))


def write_png(path, width, height, pixels):
    raw = bytearray()
    for y in range(height):
        raw.append(0)  # filter type 0
        row = pixels[y * width * 3:(y + 1) * width * 3]
        raw.extend(row)
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr)
           + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b""))
    with open(path, "wb") as f:
        f.write(png)


class Canvas:
    def __init__(self):
        self.buf = bytearray(BG * WIDTH * HEIGHT)

    def px(self, x, y, color):
        if 0 <= x < WIDTH and 0 <= y < HEIGHT:
            i = (y * WIDTH + x) * 3
            self.buf[i:i + 3] = bytes(color)

    def rect_fill(self, x0, y0, x1, y1, color):
        for y in range(max(y0, 0), min(y1 + 1, HEIGHT)):
            for x in range(max(x0, 0), min(x1 + 1, WIDTH)):
                self.px(x, y, color)

    def line(self, x0, y0, x1, y1, color):
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        x, y = x0, y0
        while True:
            self.px(x, y, color)
            if x == x1 and y == y1:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x += sx
            if e2 < dx:
                err += dx
                y += sy

    def marker(self, cx, cy, color, r=4):
        for dy in range(-r, r + 1):
            span = r - abs(dy)
            for dx in range(-span, span + 1):
                self.px(cx + dx, cy + dy, color)


# --- tiny 5x7 bitmap font for axis labels ---

FONT = {
    '0': [14, 17, 19, 21, 25, 17, 14], '1': [4, 12, 4, 4, 4, 4, 14],
    '2': [14, 17, 1, 2, 4, 8, 31], '3': [30, 1, 1, 14, 1, 1, 30],
    '4': [2, 6, 10, 18, 31, 2, 2], '5': [31, 16, 30, 1, 1, 17, 14],
    '6': [6, 8, 16, 30, 17, 17, 14], '7': [31, 1, 2, 4, 8, 8, 8],
    '8': [14, 17, 17, 14, 17, 17, 14], '9': [14, 17, 17, 15, 1, 2, 12],
    '.': [0, 0, 0, 0, 0, 12, 12], ' ': [0, 0, 0, 0, 0, 0, 0],
    'T': [31, 4, 4, 4, 4, 4, 4], 'r': [0, 24, 4, 4, 4, 4, 30],
    'u': [0, 0, 30, 17, 17, 17, 30], 'e': [0, 0, 14, 17, 30, 16, 14],
    'P': [30, 17, 17, 30, 16, 16, 16], 'd': [2, 4, 14, 18, 18, 18, 14],
    'i': [4, 0, 12, 4, 4, 4, 14], 'c': [0, 0, 14, 16, 16, 16, 14],
    't': [4, 4, 30, 4, 4, 4, 8], 'n': [0, 0, 30, 17, 17, 17, 17],
    's': [0, 0, 14, 16, 14, 1, 30],
}


def draw_text(c, text, x, y, scale=2):
    for ch in text:
        glyph = FONT.get(ch, FONT[' '])
        for gy, bits in enumerate(glyph):
            for gx in range(5):
                if bits & (16 >> gx):
                    c.rect_fill(x + gx * scale, y + gy * scale,
                                x + gx * scale + scale - 1,
                                y + gy * scale + scale - 1, FG)
        x += 6 * scale


def fmt(v):
    s = "%.1f" % v
    return s


def main():
    digest, rows = load_rows()
    targets = [r[1] for r in rows]
    preds = [r[2] for r in rows]
    lo = min(min(targets), min(preds))
    hi = max(max(targets), max(preds))
    pad = (hi - lo) * 0.05
    axis_min = float(int(lo - pad))
    axis_max = float(int(hi + pad)) + 1.0

    c = Canvas()
    x0, y0 = MARGIN_L, MARGIN_T
    x1, y1 = WIDTH - MARGIN_R, HEIGHT - MARGIN_B

    # grid + ticks
    t = axis_min
    step = 1.0
    while t <= axis_max + 1e-9:
        gx = x0 + (t - axis_min) / (axis_max - axis_min) * PLOT_W
        gy = y1 - (t - axis_min) / (axis_max - axis_min) * PLOT_H
        c.rect_fill(int(gx), y0, int(gx), y1, GRID)
        c.rect_fill(x0, int(gy), x1, int(gy), GRID)
        draw_text(c, fmt(t), int(gx) - 12, y1 + 20, 2)
        draw_text(c, fmt(t), x0 - 70, int(gy) - 7, 2)
        t += step
    # frame
    c.line(x0, y0, x1, y0, FG)
    c.line(x0, y1, x1, y1, FG)
    c.line(x0, y0, x0, y1, FG)
    c.line(x1, y0, x1, y1, FG)

    def sx(v):
        return int(x0 + (v - axis_min) / (axis_max - axis_min) * PLOT_W)

    def sy(v):
        return int(y1 - (v - axis_min) / (axis_max - axis_min) * PLOT_H)

    # ideal diagonal y = x
    c.line(sx(axis_min), sy(axis_min), sx(axis_max), sy(axis_max), DIAG)

    # Plot each archived prediction at its actual coordinates.
    for _, tv, pv in rows:
        c.marker(sx(tv), sy(pv), POINT)

    # axis titles
    tstr = "True"
    pstr = "Predicted"
    # simple spelling via available glyphs only: "True" has T,r,u,e
    draw_text(c, tstr, (x0 + x1) // 2 - 30, y1 + 45, 3)
    label = "Pred"  # vertical, drawn rotated manually below
    # draw vertical label letter by letter
    yy = (y0 + y1) // 2 - 60
    for ch in label:
        draw_text(c, ch, x0 - 105, yy, 3)
        yy += 26

    write_png(PNG_PATH, WIDTH, HEIGHT, bytes(c.buf))

    check = {
        "sourceArtifactId": ARTIFACT_ID,
        "sourceSha256": digest,
        "rowCount": len(rows),
        "targetRange": [min(targets), max(targets)],
        "predictionRange": [min(preds), max(preds)],
        "imageSize": {"width": WIDTH, "height": HEIGHT},
    }
    with open(CHECK_PATH, "w", encoding="utf-8") as f:
        json.dump(check, f, indent=2)
    print("OK rows=%d figure=%s check=%s" % (len(rows), PNG_PATH, CHECK_PATH))


if __name__ == "__main__":
    main()
