# Wine Quality 2009 · red wine baseline

Dataset: UCI Wine Quality #186, official archive https://archive.ics.uci.edu/static/public/186/wine%2Bquality.zip
Red CSV SHA-256: 4a402cf041b025d4566d954c3b9ba8635a3a8a01e039005d97d6a710278cf05e
Paper: Cortez et al. (2009), https://projects.csail.mit.edu/wiki/pub/Evodesign/SensoryEvaluationsDatabase/winequality09.pdf
Paper PDF SHA-256: 2019ea7ba6aa47c718d9233b5e63569f4bb29d5442483b0b706049fb3531b0b1
Original paper license: unknown; local private research input. Dataset: UCI CC BY 4.0.

Reproduce only Table 1 red-wine row count and selected descriptive statistics. The published regression/SVM experiment has not been reproduced.

## Fixed predictive comparison
Same original UCI red CSV (4a402cf041b025d4566d954c3b9ba8635a3a8a01e039005d97d6a710278cf05e). split.json SHA-256 944b56e99ae5c40c9114731df8158f2e204a06992e6f595dc2a6e0acdce2298f fixes 1279 training and 320 test indices before any model comparison. Train-mean baseline versus one alcohol-only linear candidate; metrics MSE/MAE on the same held-out rows. Neither metric is compared to the separate Table 1 descriptive-statistics contract.
