"""Fixed alcohol-OLS quality predictor for UCI Wine Quality red CSV.

This is a new comparison baseline, not the Cortez et al. 2009 SVM result.
"""

import csv
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
CSV = HERE / "winequality-red.csv"
SPLIT = HERE / "split.json"
OUTPUT = Path("/output")
DATA_SHA256 = "4a402cf041b025d4566d954c3b9ba8635a3a8a01e039005d97d6a710278cf05e"
FEATURES = [
    "fixed acidity", "volatile acidity", "citric acid", "residual sugar",
    "chlorides", "free sulfur dioxide", "total sulfur dioxide", "density",
    "pH", "sulphates", "alcohol",
]


def main():
    raw = CSV.read_bytes()
    if hashlib.sha256(raw).hexdigest() != DATA_SHA256:
        raise ValueError("CSV bytes do not match the fixed UCI source")
    with CSV.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter=";")
        if reader.fieldnames != FEATURES + ["quality"]:
            raise ValueError("CSV columns changed")
        data = list(reader)
    if len(data) != 1599:
        raise ValueError("CSV row count changed")
    for row in data:
        for key in FEATURES:
            value = float(row[key])
            if value != value:  # NaN check
                raise ValueError(f"non-finite value in column {key}")
    quality = [float(row["quality"]) for row in data]
    alcohol = [float(row["alcohol"]) for row in data]

    split = json.loads(SPLIT.read_text(encoding="utf-8"))
    train, test = split["train"], split["test"]
    if (split.get("datasetSha256") != DATA_SHA256 or len(train) != 1279
            or len(test) != 320 or len(set(train + test)) != 1599
            or set(train + test) != set(range(1599))):
        raise ValueError("Fixed training/test split changed")

    # Ordinary least squares on training rows only: quality ~ intercept + slope*alcohol
    n = len(train)
    xs = [alcohol[i] for i in train]
    ys = [quality[i] for i in train]
    x_mean = sum(xs) / n
    y_mean = sum(ys) / n
    sxx = sum((x - x_mean) ** 2 for x in xs)
    if sxx <= 0.0:
        raise ValueError("zero variance of alcohol on training rows; cannot fit OLS")
    sxy = sum((x - x_mean) * (y - y_mean) for x, y in zip(xs, ys))
    slope = sxy / sxx
    intercept = y_mean - slope * x_mean

    def predict(row_index):
        return intercept + slope * alcohol[row_index]

    predictions = {i: predict(i) for i in test}
    errors = [quality[i] - predictions[i] for i in test]
    mse = sum(error * error for error in errors) / len(errors)
    mae = sum(abs(error) for error in errors) / len(errors)

    OUTPUT.mkdir(parents=True, exist_ok=True)
    (OUTPUT / "metrics.json").write_text(json.dumps({"mse": mse, "mae": mae}, indent=2), encoding="utf-8")
    (OUTPUT / "model.json").write_text(json.dumps({"kind": "alcohol-ols", "intercept": intercept, "slope": slope, "trainRows": len(train), "testRows": len(test)}, indent=2), encoding="utf-8")
    with (OUTPUT / "predictions.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["index", "target", "prediction"])
        for i in sorted(test):
            writer.writerow([i, quality[i], predictions[i]])
    print(f"ok: train={len(train)} test={len(test)} mse={mse:.8f} mae={mae:.8f}")


if __name__ == "__main__":
    main()
