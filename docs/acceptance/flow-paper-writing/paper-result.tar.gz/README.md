Pi Research fixed-source export

report.md contains the saved report. manifest.json binds the selected fixed source, archived results and review evidence. Mutable workspaces and local configuration are not included.

For PDF evidence, bindings.documents records the acquired version, source, license provenance, parser identity and cited pages. Each artifact descriptor resolves to artifacts/<digest>; verify its size and SHA-256 against manifest.files. The original PDF, cited page text/images and parser output manifest retain their original bytes. Only cited page derivatives are included, so uncited pages listed in the parser manifest may not be packaged. Text ranges use UTF-16 code units and physical page numbers are one-based. An unknown license remains unknown; this local package does not establish redistribution permission.

For compiled manuscripts, bindings.publications preserves the fixed revision, successful PDF result and compiler identity. manuscripts/<revisionId>/<path> restores the editable source layout; publications/<resultId>/document.pdf is the fixed PDF. Figure provenance records declared inputs and outputs from the same job, not proof of a point-by-point scientific mapping. Unknown provenance remains unverified. bindings.figureSources resolves fixed sandbox source under sources/<sourceDigest>/<path> and inputs/outputs under artifacts/<digest>. No compilation or experiment is started by exporting.

Source modes are logical Git modes (100644 / 100755) recorded in the manifest. Windows tar headers do not reliably preserve executable bits; restore those modes from the manifest on platforms that support them. A successful process does not prove a scientific hypothesis.
